# AI Movie Studio — Python prototype

A phone-friendly Streamlit storyboard and Google Cloud Vertex AI video-generation prototype.

## Run locally

1. Install Python 3.11+.
2. In this folder, run `pip install -r requirements.txt`.
3. Configure Google Cloud Application Default Credentials for a project with Vertex AI access, billing, and permission to use a supported video model. For local development with Google Cloud CLI, run `gcloud auth application-default login` on your own trusted computer. For hosted deployment, use a securely configured service account/workload identity; never commit credential files.
4. Run `streamlit run app.py`.
5. Enter your Google Cloud project ID and supported model ID in the sidebar.
6. Import or create storyboard shots, upload approved images, and test one generation.

## Phone access

This Python app must run on a computer or hosted server. To use it from your phone anywhere, deploy it to a Python-capable host with HTTPS, access control, secure Google Cloud credentials, and persistent storage. Do **not** deploy this prototype publicly without authentication. The Streamlit interface works in mobile browsers.

## Limitations

- The old Veo 3.1 Preview models in the Gemini API were retired October 22, 2026. This prototype targets the Google Cloud Vertex AI route; model availability depends on your account, project, region and permissions.
- Google Cloud video generation is billed separately. The app does not enforce a budget cap.
- Storyboard images and video bytes are temporary session data. Download your work; persistent storage, background job recovery, and user authentication are future upgrades.
- A reference image is used as the first frame, not as a multi-image character identity reference. Model capabilities vary.
- Duration/aspect support varies by model; change requested values if Google rejects a combination.
