import os, json, time, tempfile
from pathlib import Path
import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(page_title='AI Movie Studio', page_icon='🎬', layout='wide')
st.title('🎬 AI Movie Studio')
st.caption('Storyboard first • approve references • generate one shot at a time')

if 'shots' not in st.session_state:
    st.session_state.shots = [{'title':'Shot 001 — Opening','prompt':'A wide establishing shot of a moonlit forest. Trees sway in the wind. Only environmental sound effects, no music.','duration':6,'aspect':'9:16','image':None,'video':None}]

with st.sidebar:
    st.header('Google connection')
    st.info('Veo preview Gemini API models were retired in October 2026. For production Veo, use an eligible Google Cloud Vertex AI project.')
    project = st.text_input('Google Cloud project ID', value=os.getenv('GOOGLE_CLOUD_PROJECT',''))
    location = st.text_input('Vertex AI location', value=os.getenv('GOOGLE_CLOUD_LOCATION','us-central1'))
    model = st.text_input('Video model ID', value='veo-3.1-generate-001', help='Confirm availability in your Google Cloud project before generating.')
    st.caption('Google Cloud credentials must be configured securely on the server (Application Default Credentials). Do not paste credentials into this app.')
    st.warning('Generating a video may incur Google Cloud charges. There is no automatic budget cap in this app.')

left, right = st.columns([2, 1])
with left:
    st.subheader('Storyboard')
    uploaded = st.file_uploader('Import storyboard JSON', type=['json'])
    if uploaded and st.button('Import storyboard'):
        try:
            data = json.load(uploaded)
            shots = data['shots'] if isinstance(data,dict) else data
            st.session_state.shots = [{'title':str(s.get('title','Untitled')), 'prompt':str(s.get('prompt','')), 'duration':int(s.get('duration',6)), 'aspect':s.get('aspect','9:16'), 'image':None, 'video':None} for s in shots]
            st.rerun()
        except Exception as exc:
            st.error(f'Invalid storyboard: {exc}')
    if st.button('➕ Add shot'):
        st.session_state.shots.append({'title':f'Shot {len(st.session_state.shots)+1:03d}', 'prompt':'', 'duration':6, 'aspect':'9:16','image':None,'video':None})
        st.rerun()
    export = json.dumps({'shots':[{k:v for k,v in shot.items() if k not in ('image','video')} for shot in st.session_state.shots]}, indent=2)
    st.download_button('⬇️ Export storyboard JSON', export, 'storyboard.json', 'application/json')

with right:
    st.subheader('Production checklist')
    st.write('1. Write and review each prompt.')
    st.write('2. Upload an approved first-frame image.')
    st.write('3. Confirm model access and billing.')
    st.write('4. Generate a single test clip.')
    st.write('5. Download your finished clip.')

for idx, shot in enumerate(st.session_state.shots):
    with st.expander(f"{idx+1:03d} · {shot['title']}", expanded=(idx==0)):
        shot['title'] = st.text_input('Shot title', shot['title'], key=f'title_{idx}')
        shot['prompt'] = st.text_area('Video prompt', shot['prompt'], height=130, key=f'prompt_{idx}')
        a,b = st.columns(2)
        shot['aspect'] = a.selectbox('Aspect ratio', ['9:16','16:9'], index=['9:16','16:9'].index(shot['aspect']), key=f'aspect_{idx}')
        shot['duration'] = b.selectbox('Requested seconds', [4,6,8], index=[4,6,8].index(shot['duration']) if shot['duration'] in (4,6,8) else 1, key=f'duration_{idx}')
        shot['image'] = st.file_uploader('Approved first-frame image (optional)', type=['png','jpg','jpeg'], key=f'image_{idx}')
        if shot['image']:
            st.image(shot['image'].getvalue(), caption='Approved starting frame', width=240)
        if shot.get('video'):
            st.video(shot['video'])
            st.download_button('Download MP4', shot['video'], f'shot_{idx+1:03d}.mp4', 'video/mp4', key=f'download_{idx}')
        if st.button('🎥 Generate this shot (paid API call)', key=f'generate_{idx}', disabled=not bool(project.strip() and model.strip() and shot['prompt'].strip())):
            try:
                client = genai.Client(vertexai=True, project=project.strip(), location=location.strip())
                source_args = {'prompt':shot['prompt']}
                if shot['image']:
                    suffix = Path(shot['image'].name).suffix.lower()
                    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                        f.write(shot['image'].getvalue())
                        image_path = f.name
                    try:
                        source_args['image'] = types.Image.from_file(location=image_path)
                    finally:
                        os.unlink(image_path)
                with st.spinner('Generating video. This can take several minutes...'):
                    operation = client.models.generate_videos(
                        model=model.strip(),
                        source=types.GenerateVideosSource(**source_args),
                        config=types.GenerateVideosConfig(number_of_videos=1, duration_seconds=shot['duration'], aspect_ratio=shot['aspect'])
                    )
                    for _ in range(90):
                        if operation.done: break
                        time.sleep(10)
                        operation = client.operations.get(operation)
                    if not operation.done:
                        st.warning('Still processing. Operation ID: '+str(operation.name)+'. Save this ID; the app does not yet resume jobs automatically.')
                    elif not operation.response or not operation.response.generated_videos:
                        st.error('Google returned no generated video. Check your Cloud logs and model availability.')
                    else:
                        video = operation.response.generated_videos[0].video
                        with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as f:
                            video_path=f.name
                        try:
                            client.files.download(file=video, destination=video_path)
                            shot['video']=Path(video_path).read_bytes()
                        finally:
                            os.unlink(video_path)
                        st.success('Video ready! Download it now.')
                        st.rerun()
            except Exception as exc:
                st.error(f'Generation failed: {exc}')
                st.caption('Check Vertex AI permissions, region, enabled APIs, billing, credentials and the model ID.')
        if st.button('Remove shot', key=f'remove_{idx}'):
            st.session_state.shots.pop(idx)
            st.rerun()

st.caption('Prototype: storyboard and generated clips are stored only in the active browser session/server process. Download both before closing. Add persistent storage and authentication before public deployment.')
